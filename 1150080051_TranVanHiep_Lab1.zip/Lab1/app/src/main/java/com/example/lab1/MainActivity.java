package com.example.lab1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast; // Thêm để hiển thị thông báo lỗi

public class MainActivity extends AppCompatActivity {

    // Khai báo các thành phần UI
    EditText txtX, txtY; // Nhập X, Y
    TextView txtResult; // Hiển thị kết quả
    Button btnPlus, btnMinus, btnMultiply, btnDivide, btnModulus; // Các nút phép tính

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Đặt layout cho Activity
        initControl(); // Gọi phương thức ánh xạ control và thiết lập sự kiện
    }

    // Phương thức ánh xạ đối tượng từ Java sang XML và thiết lập sự kiện
    private void initControl() {
        // Ánh xạ các control
        txtX = findViewById(R.id.txtX);
        txtY = findViewById(R.id.txtY);
        txtResult = findViewById(R.id.txtResult);
        btnPlus = findViewById(R.id.btnPlus);
        btnMinus = findViewById(R.id.btnMinus);
        btnMultiply = findViewById(R.id.btnMultiply);
        btnDivide = findViewById(R.id.btnDivide);
        btnModulus = findViewById(R.id.btnModulus);

        // Thiết lập OnClickListener chung cho tất cả các nút phép tính
        View.OnClickListener calculatorListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculate(v.getId()); // Gọi hàm tính toán
            }
        };

        btnPlus.setOnClickListener(calculatorListener);
        btnMinus.setOnClickListener(calculatorListener);
        btnMultiply.setOnClickListener(calculatorListener);
        btnDivide.setOnClickListener(calculatorListener);
        btnModulus.setOnClickListener(calculatorListener);
    }

    // Phương thức xử lý tính toán
    private void calculate(int buttonId) {
        // Kiểm tra đầu vào
        String xStr = txtX.getText().toString();
        String yStr = txtY.getText().toString();

        if (xStr.isEmpty() || yStr.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập đủ X và Y", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double x = Double.parseDouble(xStr); // Sử dụng double để hỗ trợ phép chia
            double y = Double.parseDouble(yStr);
            double result = 0;

            if (buttonId == R.id.btnPlus) {
                result = x + y;
            } else if (buttonId == R.id.btnMinus) {
                result = x - y;
            } else if (buttonId == R.id.btnMultiply) {
                result = x * y;
            } else if (buttonId == R.id.btnDivide) {
                if (y == 0) {
                    Toast.makeText(this, "Không thể chia cho 0", Toast.LENGTH_SHORT).show();
                    txtResult.setText("Lỗi: Chia 0");
                    return;
                }
                result = x / y;
            } else if (buttonId == R.id.btnModulus) {
                // Phép chia lấy dư thường dùng cho số nguyên, nên ta ép kiểu
                result = (int) x % (int) y;
            }

            // Hiển thị kết quả. Dùng String.valueOf() để chuyển đổi số sang chuỗi
            txtResult.setText(String.valueOf(result));

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Đầu vào không hợp lệ", Toast.LENGTH_SHORT).show();
            txtResult.setText("Lỗi: Đầu vào");
        }
    }
}