package com.example.lap8;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.List;

public class FoodAdapter extends ArrayAdapter<Food> {

    public FoodAdapter(@NonNull Context context, @NonNull List<Food> objects) {
        // resource ID là 0 vì chúng ta tự inflate layout
        super(context, 0, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_food, parent, false);
        }

        Food food = getItem(position);

        ImageView imgFood = convertView.findViewById(R.id.imgFood);
        TextView tvFoodName = convertView.findViewById(R.id.tvFoodName);
        TextView tvPrice = convertView.findViewById(R.id.tvPrice);
        TextView tvDescription = convertView.findViewById(R.id.tvDescription);

        if (food != null) {
            imgFood.setImageResource(food.getImageResourceId());
            tvFoodName.setText(food.getFoodName());
            tvPrice.setText(food.getPrice());
            tvDescription.setText(food.getDescription());
        }

        return convertView;
    }
}