package com.example.lap6;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class LengthConverterActivity extends Activity {

    private EditText txtLength;
    private Spinner spnLengthUnit;
    private TextView[] lblResults;

    // Các đơn vị theo thứ tự: Hải lý, Dặm, Km, Lý, Mét, Yard, Foot, Inch
    private String[] units = {
            "Hải lý", "Dặm", "Km", "Lý", "Met", "Yard", "Foot", "Inch"
    };

    // Ma trận tỉ giá (Tỉ giá từ hàng sang cột)
    private double[][] ratio = {
            // Thứ tự cột: Hải lý, Dặm, Km, Lý, Met, Yard, Foot, Inch
            {1.00000000, 1.15077945, 1.8520000, 20.2537183, 1852.0000, 2025.37183, 6076.11549, 72913.38583}, // Hải lý
            {0.86897624, 1.00000000, 1.6093440, 17.6000000, 1609.3440, 1760.00000, 5280.00000, 63360.00000}, // Dặm
            {0.53995680, 0.62137119, 1.0000000, 10.9361330, 1000.0000, 1093.61330, 3280.83990, 39370.07870}, // Km
            {0.04937365, 0.05681818, 0.0914400, 1.0000000, 91.4400000, 100.000000, 300.0000000, 3600.000000}, // Lý
            {0.00053996, 0.00062137, 0.0010000, 0.0109361, 1.0000000, 1.0936133, 3.2808399, 39.3700787}, // Mét
            {0.00049374, 0.00056818, 0.0009144, 0.0100000, 0.9144000, 1.0000000, 3.0000000, 36.0000000}, // Yard
            {0.00016458, 0.00018939, 0.0003048, 0.0033333, 0.3048000, 0.3333333, 1.0000000, 12.0000000}, // Foot
            {0.00001372, 0.00001578, 0.0000254, 0.0002778, 0.0254000, 0.0277778, 0.0833333, 1.0000000}  // Inch
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_length);

        // Kết nối View
        txtLength = findViewById(R.id.txtLength);
        spnLengthUnit = findViewById(R.id.spnLengthUnit);

        lblResults = new TextView[] {
                findViewById(R.id.lblMile),
                findViewById(R.id.lblDam),
                findViewById(R.id.lblKm),
                findViewById(R.id.lblLi),
                findViewById(R.id.lblMet),
                findViewById(R.id.lblYard),
                findViewById(R.id.lblFoot),
                findViewById(R.id.lblInch)
        };

        // Đưa dữ liệu vào Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, units);
        adapter.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spnLengthUnit.setAdapter(adapter);

        // Listener cho Spinner
        spnLengthUnit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> argo, View arg1, int arg2, long arg3) {
                LengthConverterActivity.this.convertLengthUnit();
            }
            @Override
            public void onNothingSelected (AdapterView<?> arg0) {}
        });

        // Listener cho EditText
        txtLength.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence argo, int arg1, int arg2, int arg3) {
                LengthConverterActivity.this.convertLengthUnit();
            }
            @Override
            public void beforeTextChanged (CharSequence argo, int arg1, int arg2, int arg3) {}
            @Override
            public void afterTextChanged(Editable arg) {}
        });
    }

    private void convertLengthUnit() {
        int rowIdx = spnLengthUnit.getSelectedItemPosition();
        if (rowIdx < 0) rowIdx = 0;

        String input = txtLength.getText().toString();
        double number = input.isEmpty() ? 0 : Double.valueOf(input);

        for (int i = 0; i < lblResults.length; i++) {
            double temp = number * ratio[rowIdx][i];
            // Sử dụng String.format để định dạng số thập phân gọn gàng hơn
            lblResults[i].setText(String.format("%.6f", temp));
        }
    }
}