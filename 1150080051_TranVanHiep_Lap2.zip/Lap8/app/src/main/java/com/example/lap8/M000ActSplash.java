package com.example.lap8;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler; // Cần import Handler
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class M000ActSplash extends AppCompatActivity {

    private static final long DISPLAY_TIME = 1500; // Hiển thị 1.5 giây

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Áp dụng theme Full Screen
        setTheme(R.style.Full_Screen);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m001_act_splash);

        // BÀI 1: CODE RANDOM MÀU NỀN VÀ ICON
        List<Integer> backgroundColors = Arrays.asList(
                R.color.random_blue,
                R.color.random_red,
                R.color.random_yellow
        );

        List<Integer> animalIcons = Arrays.asList(
                R.drawable.ic_penguin,
                R.drawable.ic_dog,
                R.drawable.ic_cat
        );

        Random random = new Random();

        int randomColorId = backgroundColors.get(random.nextInt(backgroundColors.size()));
        int randomIconId = animalIcons.get(random.nextInt(animalIcons.size()));

        LinearLayout mainLayout = findViewById(R.id.splash_main_layout);
        ImageView iconImageView = findViewById(R.id.splash_icon_image);

        mainLayout.setBackgroundColor(ContextCompat.getColor(this, randomColorId));
        iconImageView.setImageResource(randomIconId);

        // BÀI 1 ĐỘC LẬP: Delay 1.5 giây rồi tự đóng Activity, quay về MainActivity
        new Handler().postDelayed(
                new Runnable() {
                    public void run() {
                        // Không chuyển sang M001ActLoading nữa
                        finish(); // Chỉ đóng màn hình Splash
                    }
                },
                DISPLAY_TIME);
    }
}