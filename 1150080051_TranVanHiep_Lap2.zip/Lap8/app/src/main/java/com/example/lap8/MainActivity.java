package com.example.lap8;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnToSplash = findViewById(R.id.btn_to_splash);
        Button btnToLoading = findViewById(R.id.btn_to_loading); // Ánh xạ nút Bài 2 MỚI
        Button btnToProfile = findViewById(R.id.btn_to_profile);

        // BÀI 1: Chuyển sang màn hình Splash (M000ActSplash)
        btnToSplash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, M000ActSplash.class);
                startActivity(intent);
            }
        });

        // BÀI 2: Chuyển sang màn hình Loading (M001ActLoading)
        btnToLoading.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, M001ActLoading.class);
                startActivity(intent);
            }
        });

        // BÀI 3: Chuyển sang màn hình Profile
        btnToProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Giả định bạn đã tạo M001ActProfile cho Bài 3
                Intent intent = new Intent(MainActivity.this, M001ActProfile.class);
                startActivity(intent);
            }
        });
    }
}