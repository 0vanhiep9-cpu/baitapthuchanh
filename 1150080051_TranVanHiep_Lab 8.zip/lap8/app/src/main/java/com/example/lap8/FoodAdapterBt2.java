package com.example.lap8;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

public class FoodAdapterBt2 extends BaseAdapter {

    private Context context;
    private List<Food> foodList;

    public FoodAdapterBt2(Context context, List<Food> foodList) {
        this.context = context;
        this.foodList = foodList;
    }

    @Override
    public int getCount() { return foodList.size(); }

    @Override
    public Object getItem(int position) { return foodList.get(position); }

    @Override
    public long getItemId(int position) { return position; }

    static class ViewHolder {
        ImageView imgFoodGrid;
        TextView tvFoodNameGrid;
        TextView tvPriceGrid;
        Button btnDelete;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.grid_item_food_bt2, parent, false);

            holder = new ViewHolder();
            holder.imgFoodGrid = convertView.findViewById(R.id.imgFoodGrid);
            holder.tvFoodNameGrid = convertView.findViewById(R.id.tvFoodNameGrid);
            holder.tvPriceGrid = convertView.findViewById(R.id.tvPriceGrid);
            holder.btnDelete = convertView.findViewById(R.id.btnDelete);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        Food food = foodList.get(position);

        holder.imgFoodGrid.setImageResource(food.getImageResourceId());
        holder.tvFoodNameGrid.setText(food.getFoodName());
        holder.tvPriceGrid.setText(food.getPrice());

        holder.btnDelete.setOnClickListener(v -> {
            Toast.makeText(context, "Clicked X on: " + food.getFoodName(), Toast.LENGTH_SHORT).show();
        });

        return convertView;
    }
}
