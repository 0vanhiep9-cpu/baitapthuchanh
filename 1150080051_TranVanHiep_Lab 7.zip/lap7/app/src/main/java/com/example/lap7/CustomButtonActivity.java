package com.example.lap7; // Đảm bảo package name là lap7

import android.app.Dialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Activity xử lý logic cho Bài tập 1 và 2 (Custom Button, Toast, Dialog)
 */
public class CustomButtonActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Gán layout chi tiết của BT 1 & 2
        setContentView(R.layout.activity_custom_button);

        // Ánh xạ 2 nút ở footer (Custom Toast và Custom Dialog)
        Button btnToast = findViewById(R.id.btnToast);
        Button btnDialog = findViewById(R.id.btnDialog);

        // Đặt sự kiện click
        btnToast.setOnClickListener(v -> showCustomToast());
        btnDialog.setOnClickListener(v -> showCustomDialog());
    }

    // Phương thức hiển thị Custom Toast
    private void showCustomToast() {
        LayoutInflater inflater = getLayoutInflater();
        // Lấy layout đã thiết kế cho Toast
        View layout = inflater.inflate(R.layout.toast_custom,
                (ViewGroup) findViewById(R.id.custom_toast_container));

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_LONG);
        // Đặt vị trí: Dưới cùng và ở giữa (offset 150dp)
        toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 150);
        toast.setView(layout);
        toast.show();
    }

    // Phương thức hiển thị Custom Dialog
    private void showCustomDialog() {
        final Dialog dialog = new Dialog(this);
        // Gán layout đã thiết kế cho Dialog
        dialog.setContentView(R.layout.dialog_custom);

        // Ánh xạ nút đóng trong Dialog
        Button btnClose = dialog.findViewById(R.id.btnDialogClose);

        // Xử lý sự kiện khi nhấn nút Đóng
        btnClose.setOnClickListener(v -> dialog.dismiss());

        // Hiển thị Dialog
        dialog.show();
    }
}