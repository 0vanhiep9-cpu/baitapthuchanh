package com.example.lap8;

public class Food {
    private int imageResourceId;
    private String foodName;
    private String price;
    private String description;

    public Food(int imageResourceId, String foodName, String price, String description) {
        this.imageResourceId = imageResourceId;
        this.foodName = foodName;
        this.price = price;
        this.description = description;
    }

    // Getters
    public int getImageResourceId() {
        return imageResourceId;
    }

    public String getFoodName() {
        return foodName;
    }

    public String getPrice() {
        return price;
    }

    public String getDescription() {
        return description;
    }

    // Setters (Nếu cần cho Bài tập 3)
    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}