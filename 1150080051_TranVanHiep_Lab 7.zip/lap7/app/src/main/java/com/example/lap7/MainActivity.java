package com.example.lap7; // Đã sửa package thành lap7

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent; // Rất quan trọng để chuyển Activity
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Link đến layout Home mới bạn vừa gửi
        setContentView(R.layout.activity_main);

        Button btnCustomButton = findViewById(R.id.btnCustomButton);
        Button btnCustomSeekbar = findViewById(R.id.btnCustomSeekbar);

        // Xử lý nút Bài tập 1 và 2
        btnCustomButton.setOnClickListener(v -> {
            // Khởi chạy CustomButtonActivity
            Intent intent = new Intent(MainActivity.this, CustomButtonActivity.class);
            startActivity(intent);
        });

        // Xử lý nút Bài tập 3
        btnCustomSeekbar.setOnClickListener(v -> {
            // Khởi chạy CustomSeekbarActivity
            Intent intent = new Intent(MainActivity.this, CustomSeekbarActivity.class);
            startActivity(intent);
        });
    }
}