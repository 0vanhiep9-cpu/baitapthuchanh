package com.example.lab5;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils; // Cần có
import android.widget.FrameLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class QuickCallActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quick_call); // Dùng layout đã tạo
        initView();
    }

    private void initView() {
        // Ánh xạ các FrameLayout và ImageView dialer [cite: 388]
        findViewById(R.id.fr_mom).setOnClickListener(this);
        findViewById(R.id.fr_dad).setOnClickListener(this);
        findViewById(R.id.fr_crush).setOnClickListener(this);
        findViewById(R.id.fr_best_friend).setOnClickListener(this);
        // Giả định ImageView dialer có ID là iv_dialer (Bạn cần kiểm tra lại layout actionbar_home.xml)
        findViewById(R.id.iv_dialer).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        // Bài tập 2: Áp dụng Animation khi click
        // Sử dụng animation scale từ Luyện tập 1
        v.startAnimation(AnimationUtils.loadAnimation(this, R.anim.scale));

        if (v instanceof FrameLayout) {
            processCall((String) v.getTag()); // Xử lý gọi điện [cite: 389]
            return;
        }
        gotoDialPad(); // Xử lý mở màn hình quay số [cite: 389]
    }

    private void gotoDialPad() {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        startActivity(intent); [cite: 390]
    }

    private void processCall(String phone) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
            // Yêu cầu quyền nếu chưa được cấp [cite: 391]
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 101);
            Toast.makeText(this, "Hãy thực hiện lại sau khi cấp quyền!", Toast.LENGTH_SHORT).show();
            return;
        }
        // Thực hiện cuộc gọi [cite: 392]
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:" + phone));
        startActivity(intent); [cite: 393]
    }
}