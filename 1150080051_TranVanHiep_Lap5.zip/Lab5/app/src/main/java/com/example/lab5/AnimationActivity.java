package com.example.lab5;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class AnimationActivity extends AppCompatActivity implements View.OnClickListener {
    private ImageView ivAnimal;

    // Mảng chứa ID của các animation đã tạo cho Bài tập 1
    private final int[] ANIMATION_IDS = {
            R.anim.alpha,
            R.anim.rotate,
            R.anim.scale,
            R.anim.translate
    };
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animation); // Dùng layout mới
        initViews();
    }

    private void initViews() {
        ivAnimal = findViewById(R.id.iv_animal);

        // Ánh xạ 4 nút chính [cite: 207-210]
        findViewById(R.id.bt_alpha).setOnClickListener(this);
        findViewById(R.id.bt_rotate).setOnClickListener(this);
        findViewById(R.id.bt_scale).setOnClickListener(this);
        findViewById(R.id.bt_trans).setOnClickListener(this);

        // Ánh xạ nút Random (Bài tập 1)
        findViewById(R.id.bt_random).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.bt_alpha) {
            ivAnimal.startAnimation(AnimationUtils.loadAnimation(this, R.anim.alpha)); [cite: 213-214]
        } else if (id == R.id.bt_rotate) {
            ivAnimal.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotate)); [cite: 215-216]
        } else if (id == R.id.bt_scale) {
            ivAnimal.startAnimation(AnimationUtils.loadAnimation(this, R.anim.scale)); [cite: 216-217]
        } else if (id == R.id.bt_trans) {
            ivAnimal.startAnimation(AnimationUtils.loadAnimation(this, R.anim.translate)); [cite: 217-218]
        } else if (id == R.id.bt_random) {
            startRandomAnimation(); // Xử lý nút Random
        }
    }

    // Hàm xử lý Random cho Bài tập 1
    private void startRandomAnimation() {
        int randomIndex = random.nextInt(ANIMATION_IDS.length);
        int animationId = ANIMATION_IDS[randomIndex];
        ivAnimal.startAnimation(AnimationUtils.loadAnimation(this, animationId));
    }
}