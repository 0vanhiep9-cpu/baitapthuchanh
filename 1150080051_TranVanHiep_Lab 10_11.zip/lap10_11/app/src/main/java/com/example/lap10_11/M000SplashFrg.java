package com.example.lap10_11;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;

public class M000SplashFrg extends Fragment {
    @Override
    public View onCreateView (LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.m000_frg_splash, container, false);
        initViews();
        return rootView;
    }

    private void initViews() {
        new Handler().postDelayed(this::gotoM001Screen, 2000); // 2000ms = 2 giây [cite: 198]
    }

    private void gotoM001Screen() {
        if (getActivity() != null) {
            ((MainActivity) getActivity()).gotoM001Screen();
        }
    }
}