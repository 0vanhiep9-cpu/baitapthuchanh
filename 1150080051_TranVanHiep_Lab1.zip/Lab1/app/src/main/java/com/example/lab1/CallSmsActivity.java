package com.example.lab1;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CallSmsActivity extends AppCompatActivity { // Đã đổi tên Activity

    EditText edtPhoneNumber, edtMessage;
    Button btnDial, btnSms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_sms); // Đổi tên layout tương ứng

        edtPhoneNumber = findViewById(R.id.edtPhoneNumber);
        edtMessage = findViewById(R.id.edtMessage);
        btnDial = findViewById(R.id.btnDial);
        btnSms = findViewById(R.id.btnSms);

        btnDial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialer();
            }
        });

        btnSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSmsApp();
            }
        });
    }

    // Hàm mở trình gọi điện (Intent.ACTION_DIAL chỉ mở ứng dụng, không gọi ngay)
    private void openDialer() {
        String phoneNumber = edtPhoneNumber.getText().toString();
        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập số điện thoại", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + phoneNumber));
        startActivity(intent);
    }

    // Hàm mở trình nhắn tin
    private void openSmsApp() {
        String phoneNumber = edtPhoneNumber.getText().toString();
        String message = edtMessage.getText().toString();

        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập số điện thoại", Toast.LENGTH_SHORT).show();
            return;
        }

        // ACTION_SENDTO dùng để mở ứng dụng tin nhắn với số điện thoại đã điền
        Uri uri = Uri.parse("smsto:" + phoneNumber);
        Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
        intent.putExtra("sms_body", message); // Truyền nội dung tin nhắn
        startActivity(intent);
    }
}