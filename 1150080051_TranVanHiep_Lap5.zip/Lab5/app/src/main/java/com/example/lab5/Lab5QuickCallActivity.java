package com.example.lab5;

import android.Manifest; // [cite: 1778]
import android.content.Intent; // [cite: 1779]
import android.content.pm.PackageManager; // [cite: 1780]
import android.net.Uri; // [cite: 1781]
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils; // [cite: 1784]
import android.widget.FrameLayout; // [cite: 1785]
import android.widget.Toast; // [cite: 1786]
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random; // [cite: 1850]

public class Lab5QuickCallActivity extends AppCompatActivity implements View.OnClickListener {

    // GIẢI BÀI TẬP 2 [cite: 1850]
    private Animation[] anims;
    private Random random = new Random();
    // Hết

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab5_quickcall); // [cite: 1796]
        initView(); // [cite: 1797]
        loadAnimations();
    }

    // GIẢI BÀI TẬP 2: Load các animation [cite: 1850]
    private void loadAnimations() {
        anims = new Animation[]{
                AnimationUtils.loadAnimation(this, R.anim.alpha),
                AnimationUtils.loadAnimation(this, R.anim.rotate),
                AnimationUtils.loadAnimation(this, R.anim.scale),
                AnimationUtils.loadAnimation(this, R.anim.translate)
        };
        // Tùy chỉnh cho đẹp hơn (không lặp lại)
        for (Animation anim : anims) {
            anim.setDuration(500);
            anim.setRepeatCount(0);
        }
    }

    private void initView() {
        findViewById(R.id.fr_mom).setOnClickListener(this); // [cite: 1800]
        findViewById(R.id.fr_dad).setOnClickListener(this); // [cite: 1801]
        findViewById(R.id.fr_crush).setOnClickListener(this); // [cite: 1802]
        findViewById(R.id.fr_best_friend).setOnClickListener(this); // [cite: 1803]
        findViewById(R.id.iv_dialer).setOnClickListener(this); // [cite: 1804]
    }

    @Override
    public void onClick(View v) {
        // GIẢI BÀI TẬP 2: Áp dụng animation ngẫu nhiên [cite: 1850]
        int randomIndex = random.nextInt(anims.length);
        v.startAnimation(anims[randomIndex]);
        // Hết

        // Code gốc từ PDF (có sửa lỗi)
        int id = v.getId();
        if (id == R.id.iv_dialer) { // [cite: 1804]
            gotoDialPad(); // [cite: 1812]
            return; // [cite: 1811]
        }

        if (v instanceof FrameLayout) { // [cite: 1809]
            processCall((String) v.getTag()); // [cite: 1810]
        }
    }

    private void gotoDialPad() {
        Intent intent = new Intent(Intent.ACTION_DIAL); // [cite: 1816]
        startActivity(intent); // [cite: 1818]
    }

    private void processCall(String phone) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) // [cite: 1821]
                != PackageManager.PERMISSION_GRANTED) { // [cite: 1823]
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 101); // [cite: 1824-1825]
            Toast.makeText(this, "Hãy thực hiện lại sau khi cấp quyền!", Toast.LENGTH_SHORT).show(); // [cite: 1826]
            return; // [cite: 1827]
        }
        Intent intent = new Intent(Intent.ACTION_CALL); // [cite: 1828]
        intent.setData(Uri.parse("tel:" + phone)); // [cite: 1829] (Sửa lỗi "tel: ")
        startActivity(intent); // [cite: 1830]
    }
}