package com.example.lap8;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnLuyenTap2 = findViewById(R.id.btnBaiTapLuyenTap2);
        Button btnBaiTap1 = findViewById(R.id.btnBaiTap1);
        Button btnBaiTap2 = findViewById(R.id.btnBaiTap2);

        // Chuyển đến ListActivity (Bài tập 1 & 3)
        btnBaiTap1.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListActivity.class);
            startActivity(intent);
        });

        // Chuyển đến Bài tập 2 (GridView)
        btnBaiTap2.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, Baitap2Activity.class);
            startActivity(intent);
        });

        // Chuyển đến Luyện tập 2 (Placeholder)
        btnLuyenTap2.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, Exercise2Activity.class);
            startActivity(intent);
        });
    }
}