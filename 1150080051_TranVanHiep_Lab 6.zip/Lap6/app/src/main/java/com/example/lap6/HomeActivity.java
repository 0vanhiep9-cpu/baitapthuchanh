package com.example.lap6;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomeActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Đảm bảo tên layout là activity_home
        setContentView(R.layout.activity_home);

        Button btnBai1 = findViewById(R.id.btnBai1);
        Button btnBai2 = findViewById(R.id.btnBai2);

        // Thiết lập sự kiện cho Bài 1: Chương trình đổi tiền tệ
        btnBai1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, MoneyActivity.class);
                startActivity(intent);
            }
        });

        // Thiết lập sự kiện cho Bài 2: Chương trình đổi độ dài
        btnBai2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Sẽ trỏ tới lớp LengthConverterActivity sau khi bạn tạo
                Intent intent = new Intent(HomeActivity.this, LengthConverterActivity.class);
                startActivity(intent);
            }
        });
    }
}