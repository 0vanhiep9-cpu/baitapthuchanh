package com.example.lab5; // Thay bằng package của bạn

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }

    public void openAnimationLab(View view) {
        // Mở Luyện tập 1 + Bài tập 1
        Intent intent = new Intent(this, AnimationActivity.class);
        startActivity(intent);
    }

    public void openQuickCallLab(View view) {
        // Mở Luyện tập 2 + Bài tập 2
        Intent intent = new Intent(this, QuickCallActivity.class);
        startActivity(intent);
    }
}