package com.example.lap10_11;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private String topicName; // Để lưu trữ topicName hiện tại khi quay lại từ M003

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        showFrg(new M000SplashFrg()); // Bắt đầu bằng màn hình Splash
    }

    private void showFrg(Fragment frg) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.ln_main, frg, null) // Thay thế Fragment vào LinearLayout ln_main
                .commit();
    }

    public void gotoM001Screen() {
        // Chuyển sang màn hình danh sách Topic
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.ln_main, new M001TopicFrg(), null)
                .commit();
    }

    public void gotoM002Screen (String topicName) {
        this.topicName = topicName; // Lưu lại tên chủ đề
        M002StoryFrg frg = new M002StoryFrg();
        frg.setTopicName(topicName);
        showFrg(frg);
    }

    public void gotoM003Screen (ArrayList<StoryEntity> listStory, StoryEntity story) {
        M003DetailStoryFrg frg = new M003DetailStoryFrg();
        frg.setData(topicName, listStory, story);
        showFrg(frg);
    }

    public void backToM001Screen() {
        gotoM001Screen();
    }
}