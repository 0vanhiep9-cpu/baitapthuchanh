package com.example.lab1;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.Random;

public class DiceRollerActivity extends AppCompatActivity {

    private TextView txtDiceNumber;
    private ImageView imgDice;
    private Button btnRollDice;

    private final Random randomGenerator = new Random();

    // Mảng chứa ID tài nguyên hình ảnh (Drawable) cho 6 mặt xúc xắc
    // Đảm bảo bạn đã có các file dice_1 đến dice_6 trong res/drawable
    private final int[] diceImages = {
            R.drawable.dice_1, // Index 0 (mặt 1)
            R.drawable.dice_2,
            R.drawable.dice_3,
            R.drawable.dice_4,
            R.drawable.dice_5,
            R.drawable.dice_6  // Index 5 (mặt 6)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dice_roller);

        // Ánh xạ các control
        txtDiceNumber = findViewById(R.id.txtDiceNumber);
        imgDice = findViewById(R.id.imgDice);
        btnRollDice = findViewById(R.id.btnRollDice);

        // Thiết lập sự kiện cho nút "Tung Xúc Xắc"
        btnRollDice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rollDice();
            }
        });
    }

    private void rollDice() {
        // 1. Tạo số ngẫu nhiên từ 1 đến 6
        int diceResult = randomGenerator.nextInt(6) + 1;

        // 2. Cập nhật TextView (Xuất số ngẫu nhiên)
        txtDiceNumber.setText(String.valueOf(diceResult));

        // 3. Cập nhật ImageView (Minh họa xúc xắc)
        // Lấy ID hình ảnh tương ứng (diceResult - 1 vì mảng bắt đầu từ 0)
        int imageResourceId = diceImages[diceResult - 1];
        imgDice.setImageResource(imageResourceId);
    }
}