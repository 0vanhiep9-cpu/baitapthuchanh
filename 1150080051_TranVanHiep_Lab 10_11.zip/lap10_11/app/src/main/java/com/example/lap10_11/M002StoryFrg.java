package com.example.lap10_11;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Objects;

public class M002StoryFrg extends Fragment {
    private Context mContext;
    private String topicName; // Biến này cần được set giá trị trước khi readStory() chạy

    @Override
    public void onAttach (Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Override
    public View onCreateView (LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.m002_frg_story, container, false);
        initViews(rootView);
        return rootView;
    }

    private void initViews (View v) {
        v.findViewById(R.id.iv_back).setVisibility(View.VISIBLE);
        v.findViewById(R.id.iv_back).setOnClickListener(v1 -> backToM001Screen());
        // Hiển thị tên chủ đề (topicName đã được set qua setTopicName())
        ((TextView) v.findViewById(R.id.tv_name)).setText(topicName);

        RecyclerView rv = v.findViewById(R.id.rv_story);
        ArrayList<StoryEntity> listStory = readStory();
        StoryAdapter adapter = new StoryAdapter (listStory, mContext);

        // Gán Adapter: Lỗi thiếu trong code cũ
        rv.setAdapter(adapter);

        rv.setLayoutManager(new LinearLayoutManager(mContext));
    }

    private ArrayList<StoryEntity> readStory() {
        ArrayList<StoryEntity> listStory = new ArrayList<>();
        BufferedReader reader = null;
        try {// Đọc file truyện từ assets [cite: 695, 696]
            // Nếu topicName là NULL, lỗi FileNotFoundException: story/null.txt sẽ xảy ra.
            reader = new BufferedReader(
                    new InputStreamReader(mContext.getAssets().open("story/"+topicName+".txt"), "UTF-8"));
            String mLine;
            do {
                String title = reader.readLine();
                if (title == null) break;
                StringBuilder content = new StringBuilder();
                do {
                    mLine = reader.readLine();
                    if (mLine != null) {
                        content.append(mLine).append("\n");
                    }
                } while (mLine != null && !mLine.contains(",0")); // Dùng ",0" để đánh dấu kết thúc truyện [cite: 705]

                String storyContent = content.toString().replace(",0", "").trim();
                StoryEntity storyEntity = new StoryEntity(topicName, title, storyContent);
                listStory.add(storyEntity);
            } while (true);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return listStory;
    }

    // HÀM NÀY ĐÃ ĐƯỢC SỬA: Gán giá trị cho topicName
    public void setTopicName(String topicName){
        this.topicName = topicName;
    }

    private void backToM001Screen() {
        if (getActivity() != null) {
            ((MainActivity) getActivity()).backToM001Screen();
        }
    }
}