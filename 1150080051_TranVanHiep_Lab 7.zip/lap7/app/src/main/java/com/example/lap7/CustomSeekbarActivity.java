package com.example.lap7;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

// Triển khai giao diện OnSeekBarChangeListener
public class CustomSeekbarActivity extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener {

    private SeekBar sbRed, sbGreen, sbBlue;
    private TextView lblRValue, lblGValue, lblBValue;
    private View colorRgbView, colorCmyView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_seekbar); // Layout chính của Bài 3

        // Ánh xạ View
        sbRed = findViewById(R.id.sbRed);
        sbGreen = findViewById(R.id.sbGreen);
        sbBlue = findViewById(R.id.sbBlue);

        lblRValue = findViewById(R.id.lblRValue);
        lblGValue = findViewById(R.id.lblGValue);
        lblBValue = findViewById(R.id.lblBValue);

        colorRgbView = findViewById(R.id.colorRgbView);
        colorCmyView = findViewById(R.id.colorCmyView);

        // Thiết lập lắng nghe sự kiện cho cả 3 Seekbar
        sbRed.setOnSeekBarChangeListener(this);
        sbGreen.setOnSeekBarChangeListener(this);
        sbBlue.setOnSeekBarChangeListener(this);

        // Khởi tạo màu ban đầu
        updateColorViews();
    }

    // Phương thức chính để tính toán và cập nhật màu
    private void updateColorViews() {
        // Lấy giá trị RGB (0-255)
        int R = sbRed.getProgress();
        int G = sbGreen.getProgress();
        int B = sbBlue.getProgress();

        // Cập nhật giá trị hiển thị (VD: "R (0-255): 150")
        lblRValue.setText(String.valueOf(R));
        lblGValue.setText(String.valueOf(G));
        lblBValue.setText(String.valueOf(B));

        // 1. Tính toán màu RGB
        int rgbColor = Color.rgb(R, G, B);
        colorRgbView.setBackgroundColor(rgbColor);

        // 2. Tính toán màu CMY (Cyan, Magenta, Yellow - Màu bù)
        // Công thức: C=255-R, M=255-G, Y=255-B
        int C = 255 - R;
        int M = 255 - G;
        int Y = 255 - B;

        // Lưu ý: Android không có hàm Color.cmy, nên ta dùng Color.rgb(C, M, Y) để mô tả
        int cmyColor = Color.rgb(C, M, Y);
        colorCmyView.setBackgroundColor(cmyColor);
    }

    // Xử lý sự kiện khi Seekbar thay đổi
    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        // Chỉ cập nhật khi người dùng thay đổi (fromUser = true)
        if (fromUser) {
            updateColorViews();
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
        // Không cần làm gì
    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        // Không cần làm gì
    }
}
