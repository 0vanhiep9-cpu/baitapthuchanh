package com.example.lap8;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class Exercise2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise2);
        // Đây là màn hình cho Luyện tập 2 (ListView/RecyclerView cơ bản)
    }
}