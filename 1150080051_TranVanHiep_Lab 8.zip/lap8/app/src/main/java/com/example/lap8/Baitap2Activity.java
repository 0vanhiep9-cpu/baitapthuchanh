package com.example.lap8;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;
import java.util.ArrayList;

public class Baitap2Activity extends AppCompatActivity {

    private GridView gvFood;
    private FoodAdapterBt2 adapter;
    private ArrayList<Food> foodList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_baitap2);

        gvFood = findViewById(R.id.gvFood);

        // Dữ liệu mẫu (sử dụng lại các tài nguyên ảnh)
        foodList = new ArrayList<>();
        foodList.add(new Food(R.drawable.food1, "Hamburger", "12.000 VNĐ", "Bánh mì kẹp thịt"));
        foodList.add(new Food(R.drawable.food2, "Bánh Mì", "10.000 VNĐ", "Bánh mì kẹp thịt"));
        foodList.add(new Food(R.drawable.food3, "Bánh Bao", "12.000 VNĐ", "Nhân thịt, trứng cút"));
        foodList.add(new Food(R.drawable.food4, "Bánh Ú", "5.000 VNĐ", "Dùng cho tiết lễ"));
        foodList.add(new Food(R.drawable.food5, "Bánh Giò", "8.000 VNĐ", "Nếp, tẻ có nhân thịt"));
        foodList.add(new Food(R.drawable.food6, "Khoai Tây", "15.000 VNĐ", "Khoai tây chiên"));

        adapter = new FoodAdapterBt2(this, foodList);
        gvFood.setAdapter(adapter);
    }
}